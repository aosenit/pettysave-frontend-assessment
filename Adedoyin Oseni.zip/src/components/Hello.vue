<template>
  <h2>HOME PAGE</h2>
</template>

<script>
export default {

}
</script>

<style>
h2{
  margin-top: 50%;
  font-size: 5em;
  text-align: center;
}
</style>